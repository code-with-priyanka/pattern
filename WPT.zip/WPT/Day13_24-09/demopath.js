const p = require('path');
console.log("Name " + __dirName);

//__fileName 

//create new path 

let config = p.join(__dirName, 'config', db.properties);

FileSystem.readFile(config)

// split

//Day13/config/db.properties 