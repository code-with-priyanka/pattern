const a = require('./calc4.js');

console.log(a.add(2, 2))