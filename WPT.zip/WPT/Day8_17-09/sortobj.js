// Sort data from array of objects
var data = [{name:"Puja" , marks: 87}, {name:"Piya" , marks: 57}, {name:"Priya" , marks: 89}]

console.log("Before sorting", data);

data.sort((a1,a2) => {
    if(a1.marks >a2.marks) return 1;
    if(a1.marks <a2.marks) return -1;
    else return 0;
})

console.log("After sorting", data);

// Sort array in asending order
let arr1 = [12,65,34,98,3]

for (let i=0; i<arr1.length; i++)
{
    for (let j=i+1; j<arr1.length; j++)
    {
        temp= arr1[i];
        if(arr1[j] < arr1[i])
        {
            arr1[i]=arr1[j];
            arr1[j]=temp;
            // let temp=0;
            // temp=arr1[i];
            // arr1[i]=arr1[j];
            // arr1[j]=temp;
        }
    }
}
console.log("After sorting", arr1);

arr1.sort(function(a,b){return a-b;});// a-b asending
arr1.sort(function(a,b){return b-a;});// b-a decending
console.log("After sorting using sort function", arr1);

