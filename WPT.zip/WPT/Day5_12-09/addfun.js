// Spread Operator

function add(...a){
    sum=0;
    for(let i=0; i<a.length; i++){
        sum += a[i];// sum=sum+a;
    }
    console.log("Addition of" + a.length + "numbers is" +sum);
    
    console.log("Odd numbers from the array:")
    for(let i=0; i<a.length; i++){
         if(a[i]%2 ==1){
            console.log(a[i]);
        }
    }
}


// add(1,4,8, 9);
// add(2,8);
add(5, 3, 6, 9, 2, 5, 10);