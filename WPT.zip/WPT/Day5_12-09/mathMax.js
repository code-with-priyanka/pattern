
//2) with above concept use Math.max() method to display maximum number
function max()
{
    let a=Math.max(10,20,30,3,5);
    // console.log(a);
    return a;
}

let maxno = max();
console.log("Largest number is"+ maxno);