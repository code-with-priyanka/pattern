//5) write a function that multiplies two numbers and returns the value
function multiplication(a,b)
{
    multiply=a*b;
    return multiply;

}

multiplication(5,2);
console.log(multiply);
