function division(a,b)
{
    return a/b;
}

let a,b;
let divide=division(9,2);
console.log(divide);