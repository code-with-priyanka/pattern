//4) write a function to add 3 numbers and print the values
function add(a,b,c){
    Addition=a+b+c;
    console.log(Addition);
}


add(2,5,8);
