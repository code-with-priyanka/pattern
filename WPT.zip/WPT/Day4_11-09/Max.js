// 7) To Find max number from array write code in 3 ways as shown in lecture.

// Using For loop

// function max(arr){
//     let  max=arr[0];
//     for(let i=0; i<arr.length; i++){
//         if(arr[i]>max);
//         max=arr[i];
//     }
//     return max;
// }

// const num = [10,20,40,5,30,55,87,89,899];
// const largest_num=max(num);
// console.log("Largest number is: " + largest_num);



// Using For Each loop
// const num=[12,33,23,45,67,78,89,35,54,56,25];
// let max = num[0];

//         num.forEach(element=>
//              {
//                 if(element>max){
//                     max=element;
//                 }
//              });

// console.log("Largest element is: ", max);


// Using Sort()
const num=[12,33,23,45,67,78,89,35,54,56,25];

num.sort((a,b)=> a - b);
let max = num[num.length-1];

console.log("Largest element is: ", max);
















