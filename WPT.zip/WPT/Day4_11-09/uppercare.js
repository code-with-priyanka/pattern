const s=["hello", "html", "css","js","node js"]
s.forEach(e => {
    // let text= e.toUpperCase();
    // console.log(text);
    console.log(e.toUpperCase());
});
