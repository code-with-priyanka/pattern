// const { resolve } = require("path");

// function resolveLater(callback) {
//     let a = 10;
//     const p = new Promise(res, rej);

//     if (a == 10) {
//         return res;
//     }

//     p.then(){

//     resolve display();
//     reject display();

//     }

// }


// function display() {
//     console.log("Hello World ");
// }

// resolveLater(display)

function resolveLater(callback) {
    let a = 10;
    
    // Create a new Promise
    const p = new Promise((resolve, reject) => {
        if (a == 10) {
            resolve();  // Resolve the promise
        } else {
            reject();  // Reject the promise (you could also log something here)
        }
    });

    // Use .then() to call the callback after the promise is resolved
    p.then(() => {
        callback();  // Call the display function if resolved
    }).catch(() => {
        console.log("Promise was rejected");
    });
}

function display() {
    console.log("Hello World");
}

resolveLater(display);
