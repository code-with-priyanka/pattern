function findFact(callback) {
    // Simulate delayed execution using setTimeout (as an example)   
        const result = callback(5); // You can change the number here
        console.log(`Factorial is: ${result}`);  
}

function factorial(n) {
    // Base case
    if (n == 0 || n == 1) {
        return 1;
    }

    // Recursive case
    return n * factorial(n - 1);
}

// Call sindFact with the factorial function
findFact(factorial);
   
