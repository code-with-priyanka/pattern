let a=10
let b=20
a+b
