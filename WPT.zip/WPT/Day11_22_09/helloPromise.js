// WAP to pint "Hello World" after every 2 sec using callback and Promise

function resolveLater(callback) {
    let a = 10;

    return new Promise(
        (resolve) => {
            setInterval(() => {
                // resolve(console.log("Hello World "));
                resolve(callback());
            }, 2000);
        });
}

function display() {
    console.log("Hello World");
}

resolveLater(display);
