// 4)	number accept by command line Args

// function fetchData(callback) {
//     console.log('All arguments:', process.argv);
//     let a = process.argv[2];// read the command line arg
//     for (let i = 1; i < 11; i++) {
//         console.log(i * a);
//     }
// }

// node Args.js 12 15 18 16 ;

// fetchData()

function fetchData() {
    console.log('All arguments:', process.argv);

    // Starting from index 2, these are command line arguments
    let args = process.argv.slice(2);

    args.forEach((arg) => {
        let a = Number(arg);
        if (isNaN(a)) {
            console.log(`${arg} is not a valid number`);
            return;
        }

        console.log(`Multiples of ${a}:`);
        for (let i = 1; i <= 10; i++) {
            console.log(i * a);
        }
        console.log('---');
    });
}

fetchData();
