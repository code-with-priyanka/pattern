#include<iostream>
using namespace std;
 namespace ns
{
    class geek
    {
    public:
        void display()
        {
            cout<<"display()"<<endl;;
        }
    };
}
 
int main()
{
    // Creating Object of geek Class
    ns::geek obj;
 
    obj.display();
 
    return 0;
}
