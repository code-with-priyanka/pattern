// C++ Program to demonstrate the functioning of a friend class
#include <iostream>
using namespace std;
 class Demo {
private:
    int private_variable;
 protected:
    int protected_variable;
 public:
    Demo()
    {
        private_variable = 10;
        protected_variable = 99;
    }
     // friend class declaration
    friend class F;
};