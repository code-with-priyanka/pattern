//non constant pointer pointing to const int
#include <iostream>  
using namespace std;  
#include<string.h>
int main()  
{  
  	int a=10;
  	int y=20;
  const int	*ptr=&a;
  cout<<*ptr;
  //*ptr=5;===>error
  //a=5;==>allowed
  ptr=&y;
}