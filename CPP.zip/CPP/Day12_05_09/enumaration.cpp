#include <iostream>  
using namespace std;  
int main()
{
enum first_enum{value1=1, value2=10, value3};
first_enum e;
e=value3;
cout<<e;

}