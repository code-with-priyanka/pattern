// C++ program for dynamic allocation
#include <iostream>
using namespace std;

class Demo
{
    int * ptr;

    public:
        Demo()
        {
            ptr = new int;
            *ptr=10;
        }
        void show()
        {
            cout<<*ptr;
        }

};
int main()
{
    Demo obj;
    obj.show();

}