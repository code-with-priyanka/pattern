#include<iostream>
using namespace std;
int main()
{
    int num, rem, r, sum=0,n;
    cout<<"Enter number:";
    cin>>num;//153
    n=num;//153
    while(num != 0)
    {
        rem=num%10;//1
        num=num/10;//0
        r=rem*rem*rem;//1
        sum=sum+r;//153
    }
    if (n==sum)
    {
        cout<<"Number is Armstrong";
    }
    else
    {
        cout<<"Number is not Armstrong";
    }
}