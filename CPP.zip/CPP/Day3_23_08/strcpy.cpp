#include<iostream>
using namespace std;
void user_strcpy(char*,char*);
int main(){
    char str1[10];
    char str2[10];
    cout<<"Enter string"<<endl;
    cin>>str1;
    user_strcpy(str1,str2); 
    cout<<"Copied string is: "<<str2;

}
void user_strcpy(char* s1,char* s2)
{
        while(*s1!='\0'){
            *s2=*s1;
            s2++;
            s1++;
        }
    
    s2='\0';
}
