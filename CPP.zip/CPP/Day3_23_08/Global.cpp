#include<iostream>
using namespace std;
int y=5; // Global
void show();
int main(){
    cout<<y<<endl;
    y++;
    show();
    cout<<y<<endl;
}
void show(){
    cout<<y<<endl;
    y=0; // Another y variable is created
    cout<<y<<endl;
    y++;
    // int x=0; //Local
    // cout<<x<<endl;
    // x++;
    cout<<y<<endl;
}