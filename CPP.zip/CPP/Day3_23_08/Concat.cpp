#include<iostream>
using namespace std;
void user_strcat(char*,char*);
int main(){
    char str1[20]="hello";
    char str2[40]="world";
    cout<<str1<<endl;
    cout<<str2<<endl;
    user_strcat(str1,str2); 
    cout<<str1;

}
void user_strcat(char* s1,char* s2)
{
    while(*s1 !='\0')
    {
        *s1++;
    }
        while(*s2!='\0'){
            *s1=*s2;
            *s2++;
            *s1++;
        }
    
    *s1='\0';
}