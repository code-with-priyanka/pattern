#include<iostream>
using namespace std;
int main(){
    int a,b;
    cout<<"Enter the no:";
    cin>>a>>b;
    cout<<"before swap a is:"<<a<<"before swap b is :"<<b<<endl;
    
    a=a+b;
    b=a-b;
    a=a-b;
    cout<<"after swap a is:"<<a<<"after swap b is :"<<b<<endl;
    
    
}