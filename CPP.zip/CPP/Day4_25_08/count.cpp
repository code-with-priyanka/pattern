#include<iostream>
using namespace std;
int sum=0;
void demo(){
    // static int count=0;
    // cout<<count<<" ";
    // count++;
    int i=1;
     sum=sum+i;
    i++;
    cout<<sum<<endl;
}
int main(){
    for(int i=1;i<=5;i++){
        demo();
    }

}
