// #include<iostream>
// using namespace std;
// int main(){
//     char ch[30];
//     cout<<"Enter the char:";
//     cin>>ch;
//     char *ptr=ch;
//     char *temp=ptr;
//     int totalchar=0;
//     while(ptr!=0){
//         totalchar +=1;
//         ptr++;
//     }
//     for(int i=totalchar;i>=0;i--){
//         cout<<*(temp+i)<<endl;
//     }
// }

#include<iostream>
using namespace std;
#include<string.h>
int main()
{
    char str[20]="hello";
    char str1[20];
    int x=strlen(str)-1;
    int y=0;
    while(x>=0)
    {
        str1[y]=str[x];
        x--;
        y++;
    }
    str1[y]='\0';
    cout<<str1;
}