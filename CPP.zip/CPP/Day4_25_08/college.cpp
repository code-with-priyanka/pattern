#include<iostream>
using namespace std;
class college{

    char sname[10]; 
    int rollno;
   static char clg_name[20];
     
};
int main(){
    college s1();
    s1.rollno(20);
    
}