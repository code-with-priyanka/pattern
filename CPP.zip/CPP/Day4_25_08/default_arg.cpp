//default arguments
#include<iostream>
using namespace std;
void add(int=5,int=2,int=3,int=4);//declaration
int main(){
        add();//calling
        add(1);
        add(0,2);
        add(3,0,4);
        add(3,0,4,5);
        
}
void add(int a,int b,int c,int d){//definition
    cout<<a+b+c+d<<endl;
}