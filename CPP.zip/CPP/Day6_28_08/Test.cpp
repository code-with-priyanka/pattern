#include<iostream>
using namespace std;
class A
{
int c;
public:
	int a=5;
protected:
	int b=7;
protected:
	void display()
	{
		cout<<"in display of A\n";
	}

};
class B:protected A
{
public:
	int d;
	public:
	void show()
	{
	    	B bobj;
	bobj.display();
		cout<<a<<b;
	
	}
};

int main()
{
    B bobj;
    bobj.show();
}