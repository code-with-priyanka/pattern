// C++ program to demonstrate the working 
// of protected inheritance

#include<iostream>
using namespace std;
class Base{
    private:
        int pvt=1;
    protected:
        int prot=4;
    public:
        int pub=7;

    int getPVT(){
        return pvt;
   }
};
class ProtectedDerived : protected Base{
    public:
    int getProt(){
        return prot;
    }
    int getPub(){
        return pub;
    }
};
int main(){
    ProtectedDerived obj1;
    cout<<"private cannot access"<<endl;
    cout<<"proteactedmode= "<<obj1.getProt() <<endl;
    cout<<"public="<<obj1.getPub() <<endl;
    //cout<<obj1.pvt;
    //cout<<obj1.prot;
    //cout<<obj1.getpvt();
    return 0;
}