// C++ program to demonstrate the working 
// of private inheritance 
#include <iostream> 
using namespace std; 

class Base
{
    public:
    int pub=1;
    int getpvt(){
        return pvt;
    }

    protected:
    int prot=2;

    private:
    int pvt=3;
};

class privateDerived : private Base{
    public:
    int getprot(){
        return prot;
    }

    int getpub(){
        return pub;
    }
};

int main()
{
    privateDerived obj;
    cout<<obj.getprot()<<endl;
    cout<<obj.getpub()<<endl;
    //cout<<obj.getpvt()<<endl; //Error
    //cout<<obj.pvt; // Error
    Base obj1;
    cout<<obj1.getpvt();
}