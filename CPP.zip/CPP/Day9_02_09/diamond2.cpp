#include<iostream>
using namespace std;

class A{

    public:
        int a;
    A()
    {
        cout<<"class a is the default constructor\n";
    }
};
class B:public A
{
    public:
            int b;
    B()
    {
        cout<<"class b is default constructor\n";
    }        
};
class C:public A
{
    public:
        int c;
    C()
    {
        cout<<"class c is the default constructor\n";
    }
};
class D:public C,public B
{
    public:
     int d;
    D()
    {
        cout<<"class D is the default constructor\n";
    }
};
int main()
{
        A obj1;
        B obj2;
        C obj3;
        D obj4;
        cout<<sizeof(obj3);
}