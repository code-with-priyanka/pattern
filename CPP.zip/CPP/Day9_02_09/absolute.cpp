#include <math.h>
#include <iostream>
 using namespace std;
 int main()
{
    int val1, val2;
 
    /// finding absolute value using
    /// abs() function.
    val1 = abs(1.9);
    val2 = abs(-43);
 int	val3= abs(-2.5);
    cout << val1 << "\n";
    cout <<  val2 << "\n";
	cout <<  val3 << "\n";
	    return 0;
}