#include <iostream>  
#include<cmath>  
using namespace std;  
int main()  
{  
int base=4;  
  int exponent=2;  
  int power=pow(base,exponent);  
  cout << "Power of a given number is :" <<power;  
  return 0;  
}  