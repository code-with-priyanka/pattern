#include <iostream>  
#include<math.h>  
using namespace std;  
int main()  
{  
    float x=8.3;  
    float y=-9.9;
    cout<<"Rounded value of x is : "<<round(x);  
    cout<<"Rounded value of y is : "<<round(y);  
    return 0;  
}  