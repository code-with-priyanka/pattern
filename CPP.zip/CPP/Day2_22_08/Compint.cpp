//Compound intrest P=1000,t=2yr,r=12%,n=2/year 
// CI=A-P
// A = P(1 + R/n)^(nt)

#include<iostream>
using namespace std;
#include<cmath>
int main()
{
    float P=1000,t=2;
    float r=0.12,CI,A=1,n=2;
    
    for(int i=1; i<n*t; i++)
    {
        A=A*(1+r/n);
    }
    A=A*P;
    CI= A-P;
    cout<<"Compound interest is: "<<CI;
}
