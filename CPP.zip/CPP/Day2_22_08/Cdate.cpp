#include<iostream>
using namespace std;
class Cdate{
	int dd,mm,yy;
	public:
		Cdate(); //non arg constructor
		Cdate(int, int, int); // parametarized constructor
		void accept();
		void display() const;
		void setMonth(int);
		int getMonth() const;
	};
		Cdate :: Cdate()
		{
			cout<<"Month is";
		}
		Cdate :: Cdate(int d, int m, int y){
			dd=d;
			mm=m;
			yy=y;
		}
		void Cdate :: accept()
		{
			cout<<"Enter the dd,mm,yy \n";
			cin>>dd>>mm>>yy;
		}
		
		void Cdate :: display() const
		{
			cout<<"Today Cd is :"<<dd<<"/"<<mm<<"/"<<yy<<"\n";
		
		}
		
		void Cdate :: setMonth(int m)
		{
			mm=m;
		}
		
		int Cdate :: getMonth() const
		{
			return mm;
		}	
	

int main()
{
	const Cdate c1;
	//c1.accept();
	c1.display();
	//c1.setMonth(8);
	c1.getMonth();
	Cdate c2(21,8,2025);
	cout<<"Month is : "<<c2.getMonth();
	const Cdate c3(22,8,2025);
	cout<<"Month is : "<<c3.getMonth();
}
