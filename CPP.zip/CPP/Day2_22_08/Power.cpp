// Calculate power of a number

#include<iostream>
using namespace std;
int main()
{
    int num,p,Power=1,i;
    cout<<"Enter number and its power: ";
    cin>>num>>p;
    for(i=1;i<=p;i++)
    {
        Power=Power*num;
    }
    cout<<"\nPower is: "<<Power;
}